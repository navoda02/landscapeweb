module.exports=[99170,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_commercial_page_actions_0x61y49.js.map