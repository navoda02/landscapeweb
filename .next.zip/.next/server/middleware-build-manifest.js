globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/VBu9cLDCzWeZderjj0g0f/_buildManifest.js",
    "static/VBu9cLDCzWeZderjj0g0f/_ssgManifest.js",
    "static/VBu9cLDCzWeZderjj0g0f/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0iq1i69206cyl.js",
    "static/chunks/10muk0s002m9w.js",
    "static/chunks/3peubv2924kx4.js",
    "static/chunks/turbopack-0-crjjlsgf_t5.js"
  ]
};
