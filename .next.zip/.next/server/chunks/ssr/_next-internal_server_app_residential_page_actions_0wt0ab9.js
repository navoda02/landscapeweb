module.exports=[29470,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_residential_page_actions_0wt0ab9.js.map