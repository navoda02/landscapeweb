module.exports=[84199,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_nature-play_page_actions_1prz-ui.js.map